<?php

return [
    'site_title' => 'CVS 2',

];
